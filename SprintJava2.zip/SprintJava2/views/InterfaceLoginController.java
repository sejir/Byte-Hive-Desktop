/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.SprintJava2.views;

import edu.SprintJava2.entities.Users;
import edu.SprintJava2.services.UsersCRUD;
import edu.SprintJava2.services.UsersSession;
import java.io.File;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javax.swing.JOptionPane;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;

/**
 * FXML Controller class
 *
 * @author chayma
 */
public class InterfaceLoginController implements Initializable {
   private static String profilePicture="";
   private static final String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

   @FXML
    private TextField TFname;
    @FXML
    private TextField TFlastname;
    @FXML
    private TextField TFemail;
    @FXML
    private PasswordField TFpassword;
    @FXML
    private ImageView sigupimage;
    private String cImageUrl = "";
    @FXML
    private PasswordField TFpassword2;
    @FXML
    private TextField TFemail2;
    @FXML
    private CheckBox cbox;
    @FXML
    private Label errorlabel1;
    @FXML
    private ComboBox<String> combobox1;
    ObservableList<String> list = FXCollections.observableArrayList("Provider","Host","Camper");
    ValidationSupport validationSupport = new ValidationSupport();


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
      combobox1.setItems(list);
      // validationSupport.registerValidator(TFname,Validator.createEmptyValidator("name is required"));
       // validationSupport.registerValidator(TFlastname,Validator.createEmptyValidator("lastname is required"));

    }    

    @FXML
    private void ajouteruser(ActionEvent event) {
      Pattern pattern = Pattern.compile(regex);
       UsersCRUD cc = new UsersCRUD(); 
        Matcher matcher = pattern.matcher(TFemail.getText());
        if (cImageUrl.equals("")) {
           JOptionPane.showMessageDialog(null,"select a picture");
        }else if (TFname.getText().length() < 3) {
           JOptionPane.showMessageDialog(null,"enter a valid name");
        } else if (TFlastname.getText().length() < 3) {
           JOptionPane.showMessageDialog(null,"enter your lastname ");
        } else if (!matcher.matches()) {
           JOptionPane.showMessageDialog(null,"enter a valid email format");
        } else if (TFpassword.getText().length() < 6) {
JOptionPane.showMessageDialog(null,"enter a strong password");
        } else if (!cc.validateEmail(TFemail.getText())) {
            JOptionPane.showMessageDialog(null,"This mail is already used");
        } else {
        JOptionPane.showMessageDialog(null,"Please wait we are creating your account");
        Users u = new Users();
        u.setName(TFname.getText());
        u.setLastname(TFlastname.getText());
        u.setEmail(TFemail.getText());
        u.setPassword(TFpassword.getText());
        u.setRole(combobox1.getValue());
        u.setProfilePicture(cImageUrl);
        if(cc.ajouteruser(u))
        { 
           //JOptionPane.showMessageDialog(null,"Your Account has been successfully created!");
           // NewFXMain.setScene("Userprofile");   
            System.out.println("User added");
            JOptionPane.showMessageDialog(null,"Your Account has been successfully created!");
            TFname.setText("");
            TFlastname.setText("");
            TFemail.setText("");
            TFpassword.setText("");
            combobox1.setValue("");
            cImageUrl="";
            
            
        }else {
            System.out.println("User was not added");
        }
        }
    }
    

    @FXML
    private void validate(ActionEvent event) throws Exception{
        Users u = new Users(); 
        UsersCRUD cc = new UsersCRUD(); 
       String access = (combobox1.getItems().toString());

        
        boolean result = UsersCRUD.Login(TFemail2.getText(), TFpassword2.getText());
        if((UsersSession.getRole().equals("Admin")) && (true==result))
        {
         NewFXMain.setScene("InterfaceAdmin");    
        } else if ((UsersSession.getRole().equals("Camper")) && (true==result)) {
            
           NewFXMain.setScene("Interface_Camper");
        } else if ((UsersSession.getRole().equals("Provider")) && (true==result)) {
           NewFXMain.setScene("Interface_Provider");        
        } else if ((UsersSession.getRole().equals("Host")) && (true==result)) {
           NewFXMain.setScene("Interface_Host"); 
        } 
        
    }
       
    

    @FXML
    private void uploadsiguppic(ActionEvent event) {
         FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        fileChooser.setInitialDirectory(new File("C:\\Users\\chayma\\Documents\\NetBeansProjects\\SprintJava2\\src\\edu\\SprintJava2\\images"));
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            String TempprofilePicture = file.toURI().toString();
            System.out.println(TempprofilePicture);
            profilePicture= file.getName();
            System.out.println(profilePicture);
            Image image = new Image(TempprofilePicture);
            sigupimage.setImage(image);
            cImageUrl = TempprofilePicture;
        }
    }

    @FXML
    private void checkbox(ActionEvent event) {
        if (cbox.isSelected()){
            TFpassword2.setPromptText(TFpassword2.getText());
            TFpassword2.setText("");
            TFpassword2.setDisable(true);
        }else {
            TFpassword2.setText(TFpassword2.getPromptText());
            TFpassword2.setPromptText("");
            TFpassword2.setDisable(false);
        }
    }
    
}
